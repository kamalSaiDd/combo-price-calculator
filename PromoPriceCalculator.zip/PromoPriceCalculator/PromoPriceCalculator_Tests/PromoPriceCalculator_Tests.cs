using System;
using Xunit;


namespace PromoPriceCalculator_Tests
{
    public class PromoPriceCalculator_Tests
    {
        
        [Fact]
        public void sale_item_A_count_1_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateA(1);
            Assert.True(result == 50);
        }

        [Fact]
        public void sale_item_A_count_3_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateA(3);
            Assert.True(result == 130);
        }

        [Fact]
        public void sale_item_A_count_5_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateA(5);
            Assert.True(result == 230);
        }

        [Fact]
        public void sale_item_A_count_6_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateA(6);
            Assert.True(result == 260);
        }

        [Fact]
        public void sale_item_A_count_8_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateA(8);
            Assert.True(result == 360);
        }

        [Fact]
        public void sale_item_B_count_1_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateB(1);
            Assert.True(result == 30);
        }

        [Fact]
        public void sale_item_B_count_2_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateB(2);
            Assert.True(result == 45);
        }

        [Fact]
        public void sale_item_B_count_3_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateB(3);
            Assert.True(result == 75);
        }

        [Fact]
        public void sale_item_B_count_4_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateB(4);
            Assert.True(result == 90);
        }

        [Fact]
        public void sale_item_B_count_5_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateB(5);
            Assert.True(result == 120);
        }

        [Fact]
        public void sale_item_C_D_count_1_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateCAndD(1, 0);
            Assert.True(result == 20);
        }

        [Fact]
        public void sale_item_C_D_count_2_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateCAndD(1, 1);
            Assert.True(result == 30);
        }

        [Fact]
        public void sale_item_C_D_count_3_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateCAndD(1, 2);
            Assert.True(result == 45);
        }

        [Fact]
        public void sale_item_C_D_count_4_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateCAndD(2, 2);
            Assert.True(result == 60);
        }

        [Fact]
        public void sale_item_C_D_count_3_c2_test()
        {
            var _calculator = new PromoPriceCalculator.PromoPriceCalculator();

            var result = _calculator.calculateCAndD(2, 1);
            Assert.True(result == 50);
        }
    }
}
