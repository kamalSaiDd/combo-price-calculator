﻿using System;

namespace PromoPriceCalculator
{
    public class PromoPriceCalculator
    {
        public static int A = 50;
        public static int B = 30;
        public static int C = 20;
        public static int D = 15;

        public static double saleItemCountA = 3;
        public static double saleItemCountB = 2;
        public static double saleItemCountCAndD = 2;

        public static double salePriceA = 130;
        public static double salePriceB = 45;
        public static double salePriceCAndD = 30;

        // 3 of A's = 130;
        // 2 of B's = 45
        // c & D = 30

        public PromoPriceCalculator()
        {

        }

        public double calculateA(int noOfItems)
        {
            if (noOfItems >= saleItemCountA)
            {
                double salesTobeCounted = Math.Floor(noOfItems / saleItemCountA);
                double singleItemsCalculated = (salesTobeCounted * saleItemCountA);

                return (salesTobeCounted * salePriceA)
                        + ((noOfItems - singleItemsCalculated) * A);
            }
            else
            {
                return noOfItems * A;
            }
        }

        public double calculateB(int noOfItems)
        {
            if (noOfItems >= saleItemCountB)
            {
                double salesTobeCounted = Math.Floor(noOfItems / saleItemCountB);
                double singleItemsCalculated = (salesTobeCounted * saleItemCountB);

                return (salesTobeCounted * salePriceB)
                        + ((noOfItems - singleItemsCalculated) * B);
            }
            else
            {
                return noOfItems * B;
            }
        }

        public double calculateCAndD(int noOfCItems, int noOfDItems)
        {
            double totalCAndD = (noOfCItems + noOfDItems);
            if (totalCAndD >= saleItemCountCAndD)
            {
                double salesTobeCounted = Math.Floor(totalCAndD / saleItemCountCAndD);
                double singleItemsCalculated = (salesTobeCounted * saleItemCountCAndD);

                var comboPrice = (salesTobeCounted * salePriceCAndD);

                double nonComboPrice = 0;
                // As it is count 2 for Combo sale we cna check ne or other to price.
                if (noOfCItems > noOfDItems)
                {
                    nonComboPrice += ((totalCAndD - singleItemsCalculated) * C);
                }
                else
                {
                    nonComboPrice += ((totalCAndD - singleItemsCalculated) * D);
                }
                return comboPrice + nonComboPrice;
            }
            else
            {
                return calculateNonComboCAndD(noOfCItems, noOfDItems);
            }
        }

        private static int calculateNonComboCAndD(int noOfCItems, int noOfDItems)
        {
            var totalPriceCAndD = 0;
            if (noOfCItems > 0)
            {
                totalPriceCAndD += (noOfCItems * C);
            }
            if (noOfDItems > 0)
            {
                totalPriceCAndD += noOfDItems * D;
            }

            return totalPriceCAndD;
        }
    }
}
